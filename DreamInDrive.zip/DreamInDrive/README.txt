转载请标注b站视频链接或github地址
b站：https://www.bilibili.com/video/BV1Yq421c7Ny/
github：https://github.com/sinsyamoses/musicscores